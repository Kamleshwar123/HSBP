import SalonImage from '../public/assets/images/appoint-image.webp'
const IMAGES = {
    SalonImage: SalonImage,
}
export default IMAGES