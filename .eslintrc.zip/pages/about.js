import Layout from "../layout";
import Head from "next/head";
export default function About() {
    return(
        <>
        <Head>
        <title>i am about</title>
        <meta name="description" content="Home service beauty Parlour" />
        <link rel="icon" href="/favicon.ico" />
      </Head><Layout
            title="helllo dldsfsdfdskl"
            description="hello about"
        >
                <p>i am abouwfdskofsfsdfsdfsdf;f;dfsdkflsdt</p>
            </Layout></>
    )

}