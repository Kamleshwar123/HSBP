const SalonHead = () => {
    return (
        <div className='services-head'>
            <h1>Near by Salons</h1>
            <p>200+ tech enabled salons, serving you quality services across 40+ cities</p>
        </div>
    )
}
export default SalonHead