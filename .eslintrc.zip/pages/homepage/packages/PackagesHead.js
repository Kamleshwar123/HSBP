const PackagesHeading = () => {
    return (
        <div className='services-head'>
            <h1>Beauty Packages</h1>
            <p>We provide special offers for students and corporates</p>
        </div>
    )
}
export default PackagesHeading