const TestimonialHeading = () => {
    return (
        <div className='services-head'>
            <h1>Institute</h1>
            <p>100+ Tech enabled Institute, Serving you quality services across 60+ cities</p>
        </div>
    )
}
export default TestimonialHeading