import ServicesHeading from "./servicesHead"
import ServiceList from "./serviceList"
const Services= () => {
  return (
    <>
    <ServicesHeading/>
  <ServiceList />
    </>
  )
}

export default Services