const ServicesHeading = () => {
    return (
        <div className='services-head'>
            <h1>Beauty Services</h1>
            <p>We provide special offers for students and corporates</p>
        </div>
    )
}
export default ServicesHeading