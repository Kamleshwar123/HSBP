const BookAppointmentHead = () => {
    return (
        <div className='services-head'>
            <h1>Book Appointment</h1>
            <p>Lorem ipsum dolor sit amet, consectetur adipisci elitsed eiusmod</p>
        </div>
    )
}
export default BookAppointmentHead