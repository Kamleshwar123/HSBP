
const ProdHeading = () => {
    return (
        <div className='services-head'>
            <h1>Products</h1>
            <p>50+ salon professional brands delivered nationally to your doorsteps</p>
        </div>
    )
}
export default ProdHeading