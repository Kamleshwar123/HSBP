const FranchisesHeading = () => {
    return (
        <div className='services-head'>
            <h1>Franchises</h1>
            <p>200+ Tech enabled salons, Serving you quality services across 40+ cities</p>
        </div>
    )
}
export default FranchisesHeading