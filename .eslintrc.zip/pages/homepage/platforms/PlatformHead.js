
const PlatHeading = () => {
    return (
        <div className='services-head'>
            <h1>India's Largest Platform</h1>
            <p>FOR ALL YOUR BEAUTY SALON NEEDS</p>
        </div>
    )
}
export default PlatHeading