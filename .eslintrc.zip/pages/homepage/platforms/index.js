import PlatformsList from "./PlatformsList";
import PlatHeading from "./PlatformHead";
const PlatForms = () =>{
    return(
        <>
        <PlatHeading />
        <PlatformsList />
        </>
    )
}
export default PlatForms